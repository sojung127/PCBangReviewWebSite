﻿<!DOCTYPE HTML>
<html>
    <head>
    </head>
    
    <body>

    <?php

        $username="root";
        $password="1234"; //비밀번호
        $database="root-pcreview"; //이거는 DBMS에 있는 스키마 이름.

    ?> 


    </body>

</html>